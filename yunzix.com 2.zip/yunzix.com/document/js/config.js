(function(self){

  self.Sensoro = self.Sensoro || {};
  self.Sensoro.API = 'http://192.168.208.9:5000';

})(window);