/**
  * 首页
  */

Sensoro.app.controller('AppStoreCtrl', function () {
  console.log('appstore');
});