/**
  * 首页
  */

Sensoro.app.controller('DocumentCtrl', function () {
  console.log('document');
});