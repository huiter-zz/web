/**
  * 首页
  */

Sensoro.app.controller('FaceCtrl', function () {
  console.log('face');
});