/**
  * 首页
  */

Sensoro.app.controller('WechatCtrl', function () {
  console.log('wechat');
});