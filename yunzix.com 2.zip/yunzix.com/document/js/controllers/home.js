/**
  * 首页
  */

Sensoro.app.controller('HomeCtrl', function () {
  console.log('home');
});