/**
  * 首页
  */

Sensoro.app.controller('MenuCtrl', function () {
  console.log('menu');
});