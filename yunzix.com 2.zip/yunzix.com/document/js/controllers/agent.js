/**
  * 首页
  */

Sensoro.app.controller('AgentCtrl', function () {
  console.log('agent');
});