/**
  * 登陆模块
  */

Sensoro.app.controller('LoginCtrl', function () {
  console.log('login');
});