/**
  * 首页
  */

Sensoro.app.controller('ShakeCtrl', function () {
  console.log('shake');
});