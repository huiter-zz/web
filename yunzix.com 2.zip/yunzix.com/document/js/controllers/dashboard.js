/**
  * 首页
  */

Sensoro.app.controller('DashboardCtrl', function () {
  console.log('dashboard');
});