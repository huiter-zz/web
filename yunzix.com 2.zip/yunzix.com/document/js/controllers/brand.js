/**
  * 首页
  */

Sensoro.app.controller('BrandCtrl', function () {
  console.log('brand');
});