/**
  * 首页
  */

Sensoro.app.controller('FaceCreateCtrl', function () {
  console.log('facecreate');
});