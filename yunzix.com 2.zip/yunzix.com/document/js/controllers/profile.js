/**
  * 首页
  */

Sensoro.app.controller('ProfileCtrl', function () {
  console.log('profile');
});