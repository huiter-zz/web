/**
  * 首页
  */

Sensoro.app.controller('BoxCtrl', function () {
  console.log('box');
});