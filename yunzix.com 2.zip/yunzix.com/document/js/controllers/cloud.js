/**
  * 首页
  */

Sensoro.app.controller('CloudCtrl', function () {
  console.log('cloud');
});