/**
  * 首页
  */

Sensoro.app.controller('StoreCtrl', function () {
  console.log('store');
});